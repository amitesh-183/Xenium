export default function Offer() {
  return (
    <div>
      <h1 className="text-center py-6">Presale Offer</h1>
      
    </div>
  );
}
